﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Excel;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using System.Drawing;
using System.Diagnostics.Eventing.Reader;
using System.Reflection;
using System.Diagnostics;

namespace ex03
{
    public partial class ThisAddIn
    {
        public int years = 2024;
        public int months = 1;
        public int days = 1;
        public string[] actstrings = { };
        public int step = 1;

        public int colums = 0;
        public string[] strings = { "출고이력추적", "순번", "관리코드", "명칭/단위", "생산월", "생산수량", "출고수량", "생산단위수량", "출고단위수량" };
        public string[] strings2 = { "개별재고 출고(사용)이력[]", "순번", "일자", "거래처", "수량", "잔여수량", "단위재고", "구분" };
        public string[] strings3 = { "개별재고/유통기한 현황표 [완제품]", " 순번", "관리코드", "명칭/규격/수량", "수량?▼", "단위재고", "입고일", "유통기한	잔여일" };


        public int[] columpoint = { 0, 9, 17 };
        public int Row = 3;
        private Excel.Range previousCell; // 이전에 선택된 셀


        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            // 시트 선택 변경 이벤트 핸들러 등록
              this.Application.SheetChange += new Excel.AppEvents_SheetChangeEventHandler(Application_SheetChange);


        }



        void Application_SheetChange(object Sh, Excel.Range Target)
        {

            // 이벤트 무한 호출 방지: 이벤트 일시적으로 비활성화

            set_report(); // 셀 값을 변경하는 작업이 여기서 이루어짐
        }
          
        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            // Add-in 종료 시 이벤트 핸들러 제거
            this.Application.SheetChange += new Excel.AppEvents_SheetChangeEventHandler(Application_SheetChange);
        }

        #region VSTO에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion


        public void set_report()   //------------ 매뉴 생성 초기..
        {

            string[] sub = actstrings;
            if (sub.Length == 0) return;
            /*
                    style.Font.Name = "Verdana";
                    style.Font.Size = 12;
                    style.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                    style.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Gray);
                    style.Interior.Pattern = Excel.XlPattern.xlPatternSolid;
             */
            Excel.Worksheet ws = Globals.ThisAddIn.Application.ActiveSheet;

            int index = 1;

            if (Row == 3)
            {


                foreach (string st in sub)
                {


                    Excel.Range range = ws.Cells[3, index + colums];
                    if (st == sub[0])
                    {
                        range = ws.Cells[2, 4 + colums];
                        range.Value = st;
                        range.Style.Font.Name = "Segoe UI";
                        range.Style.Font.Size = 15;
                        range.Style.Font.Bold = true;
                        range.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkRed);

                    }
                    else
                    {

                        index++;
                        range.Value = st;
                        range.Style.Font.Name = "Segoe UI";
                        range.Style.Font.Size = 12;
                        range.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                        range.Interior.Color = System.Drawing.ColorTranslator.ToOle(ColorTranslator.FromHtml("#EAECF4"));
                        range.Interior.Pattern = Excel.XlPattern.xlPatternSolid;


                    }


                    range.Columns.AutoFit();
                }

                Row++;

            }
            else
            {
                Excel.Range range = ws.Cells[4, index + colums];
                Row = create_date(Row, sub.Length - 1);
                range.Columns.AutoFit();
            }



        }
        public int create_date(int sRow, int stlen)  //--------------- 날짜 생성
        {
            Excel.Worksheet ws = Globals.ThisAddIn.Application.ActiveSheet;
            int cnt = 0;




            if (days == 1)
            {
                Excel.Range range2 = ws.Cells[sRow, 1 + colums];
                range2.Value = years + "년" + months + "월" + (days++) + "일";

                range2.Columns.AutoFit();

                mborders(1 + colums, sRow - 1, stlen + 1 + colums, Row + 1);  // 문서 태두리 border

            }
            else
            {
                for (int i = 1; i < stlen; i++) //-------- 입력이 다 끝나면 다음 날짜 생성..
                {


                    var cellValue = ws.Cells[Row, i + 1 + colums].Value;

                    // 셀 값이 null이 아니고, 숫자인지 확인 (문자열 포함)
                    if (cellValue != null && double.TryParse(cellValue.ToString(), out double result))
                    {
                        cnt++;  // 셀 값이 숫자일 경우 cnt 증가
                    }
                }

                if (cnt == stlen - 1)
                {

                    sRow++;
                    Excel.Range range2 = ws.Cells[sRow, 1 + colums];
                    range2.Value = years + "년" + months + "월" + (days++) + "일";

                    if (sRow >= 4) Row = create_date(sRow, stlen - 1);
                    range2.Columns.AutoFit();
                    mborders(1 + colums, sRow, stlen + 1 + colums, sRow + 1);  // 문서 태두리 border
                }
            }


            Debug.WriteLine("Row: " + sRow);
            return sRow;

        }

        private void mborders(int Left, int Up, int Right, int Down)  // 보더 생성
        {
            int Wd = Right - Left;
            int Hd = Down - Up;
            Excel.Worksheet ws = Globals.ThisAddIn.Application.ActiveSheet;


            for (int i = 0; i < Wd; i++)
                for (int j = 0; j < Hd; j++)
                {
                    Range actCell = ws.Cells[Up + j, Left + i];


                    actCell.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                    actCell.Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = Excel.XlBorderWeight.xlThin;

                    // 하단 테두리 설정
                    actCell.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                    actCell.Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = Excel.XlBorderWeight.xlThin;

                    // 왼쪽 테두리 설정
                    actCell.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                    actCell.Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = Excel.XlBorderWeight.xlThin;

                    // 오른쪽 테두리 설정
                    actCell.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                    actCell.Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = Excel.XlBorderWeight.xlThin;
                }


        }
    }
}


