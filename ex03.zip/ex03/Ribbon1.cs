﻿using Microsoft.Office.Tools.Ribbon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex03
{
    public partial class Ribbon1
    {
        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {

        }

        

        private void button1_Click_1(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.actstrings = Globals.ThisAddIn.strings;  // 문서 종류선택
            Globals.ThisAddIn.colums = Globals.ThisAddIn.columpoint[2];
            Globals.ThisAddIn.Row = 3;

            Globals.ThisAddIn.years = 2024;
            Globals.ThisAddIn.months = 1;
            Globals.ThisAddIn.days = 1;
            Globals.ThisAddIn.set_report();

        }

        private void button2_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.actstrings = Globals.ThisAddIn.strings2;  // 문서 종류선택
            Globals.ThisAddIn.colums = Globals.ThisAddIn.columpoint[1];
            Globals.ThisAddIn.Row = 3;

            Globals.ThisAddIn.years = 2024;
            Globals.ThisAddIn.months = 1;
            Globals.ThisAddIn.days = 1;
            Globals.ThisAddIn.set_report();

        }

        private void button3_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.actstrings = Globals.ThisAddIn.strings;  // 문서 종류선택
            Globals.ThisAddIn.colums = Globals.ThisAddIn.columpoint[0];
            Globals.ThisAddIn.Row = 3;

            Globals.ThisAddIn.years = 2024;
            Globals.ThisAddIn.months = 1;
            Globals.ThisAddIn.days = 1;
            Globals.ThisAddIn.set_report();

        }
    }
}
